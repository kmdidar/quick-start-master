(function($){
    'use strict';

    var slider = $('.home-slider');
    slider.owlCarousel({
        items: 1
    });


})(jQuery);